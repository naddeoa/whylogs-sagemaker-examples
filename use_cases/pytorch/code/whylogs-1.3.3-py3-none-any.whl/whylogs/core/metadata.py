import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from uuid import uuid4

from whylogs.core.utils.timestamp_calculations import to_utc_milliseconds

diagnostic_logger = logging.getLogger(__name__)

WHYLABS_TRACE_ID_KEY = "whylabs.traceId"
CREATION_TIMESTAMP_KEY = "whylogs.creationTimestamp"
DATASET_TIMESTAMP_KEY = "whylogs.datasetTimestamp"
USER_TAGS_KEY = "whylogs.user.tags"
NAME_KEY = "whylogs.name"


def _populate_common_profile_metadata(
    metadata: Optional[Dict[str, str]] = None,
    *,
    name: Optional[str] = None,
    column_name: Optional[str] = None,
    trace_id: Optional[str] = None,
    tags: Optional[List[str]] = None,
    timestamp: Optional[int] = None,
    segment_key_values: Optional[List[Dict[str, str]]] = None,
) -> Dict[str, Any]:
    if trace_id is not None:
        if not isinstance(trace_id, str):
            raise ValueError(
                f"trace_id must be a string if supplied. trace_id={trace_id} was passed with type: {type(trace_id)}."
            )
        if not trace_id:
            diagnostic_logger.warning("trace_id was supplied but empty. A new uuid will be used instead.")

    if metadata is None:
        metadata = dict()
    if WHYLABS_TRACE_ID_KEY not in metadata:
        if not trace_id:
            trace_id = str(uuid4())
        metadata[WHYLABS_TRACE_ID_KEY] = trace_id
    elif metadata[WHYLABS_TRACE_ID_KEY] != trace_id:
        diagnostic_logger.warning(
            f"trace_id was specified as {trace_id} but there is already a trace_id defined "
            f"in metadata[{WHYLABS_TRACE_ID_KEY}]: {metadata[WHYLABS_TRACE_ID_KEY]}"
        )

    if CREATION_TIMESTAMP_KEY not in metadata:
        metadata[CREATION_TIMESTAMP_KEY] = str(to_utc_milliseconds(datetime.now(timezone.utc)))
    if timestamp and DATASET_TIMESTAMP_KEY not in metadata:
        metadata[DATASET_TIMESTAMP_KEY] = str(timestamp)

    if name and NAME_KEY not in metadata:
        metadata[NAME_KEY] = name
    if tags and USER_TAGS_KEY not in metadata:
        metadata[USER_TAGS_KEY] = json.dumps(sorted(set(tags)))

    return metadata
