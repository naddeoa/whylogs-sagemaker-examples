_proc_error_message = """
Install whylogs with extra [proc] for process based logging: pip install whylogs[proc]. If you can't
build the faster_fifo module then you can try the alternative whylogs[proc-mp] that uses the built in
python queue module, at the cost of performance.
"""
