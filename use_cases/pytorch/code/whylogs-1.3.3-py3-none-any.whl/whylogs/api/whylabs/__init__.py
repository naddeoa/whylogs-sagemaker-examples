from whylogs.api.whylabs.session.session_manager import init

__ALL__ = [init]
